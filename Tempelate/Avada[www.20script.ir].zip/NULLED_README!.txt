Upload & Activate WordPress Web Template -> ( ...\Avada Theme\Avada_v5.8\NULLED\Avada\ )
Upload & Activate WordPress Plugin "Fusion Builder" Nulled Version Manually -> ( ...\Avada Plugins\fusion-builder_v1.8_nulled.zip )
* Nulled Latest Version Additional Plugins -> ( ...\Avada Plugins\additional-plugins\ ) | Upload & Activate Manually